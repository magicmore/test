#!/bin/bash

word=$1
curl http://dict.baidu.com/s?wd=$word >websap.html
